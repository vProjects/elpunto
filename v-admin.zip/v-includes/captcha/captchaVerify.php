<?php
	session_start();
	/* a simple form check */
	if(isset( $_POST['secure']))
	{
		if($_POST['secure'] != $_SESSION['security_number'])
		{
			$error = "OOOK! Here's what you must do: click Start -> Run and write calc.";
		}
		else
		{
			$error = "Man, you're good! Your result is correct.";
		}
			echo $error;

	}
?>
