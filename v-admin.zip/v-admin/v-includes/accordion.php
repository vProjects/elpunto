<div class="span4 neutral">
           <div class="accordion" id="accordion2">
           	<!-- accordian group starts here -->
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne" onclick="loadFile('view.dashboard.php')">
                      Dashboard
                    </a>
                  </div>
                  <div id="collapseOne" class="accordion-body collapse" style="height: 0px;">
                    <div class="accordion-inner" onClick="loadFile('view.seo.php?abc=vasu')">SEO Management</div>
                     <div class="accordion-inner" onClick="loadFile('view.analytics.php')">
                      Analytics
                    </div> <div class="accordion-inner" onclick="loadFile('view.postArticle.php')">
                      Post An Article
                    </div> <div class="accordion-inner" onClick="loadFile('view.changepassword.php')">
                      Change Your Password
                    </div> <div class="accordion-inner" onclick="loadFile('view.client_form.php')" >
                      Add Client
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
                      Manage website content
                    </a>
                  </div>
                  <div id="collapseTwo" class="accordion-body collapse" style="height: 0px;">
                    <div class="accordion-inner" onclick="loadFile('view.homepage.php')" >
                      Home Page
                    </div>
                     <div class="accordion-inner" onclick="loadFile('view.otherpages.php')" >
                      Other Pages
                    </div> 
                    <div class="accordion-inner" onclick="loadFile('view.updateSliderImage.php')">
                     Update Slider Image
                    </div>
                    <div class="accordion-inner" onclick="loadFile('view.fileuploader.php')">
                      File Uploader
                    </div> 
                    <div class="accordion-inner" onclick="loadFile('view.changeMenu_horizontal.php')">
                      Manage Horizontal Menu
                    </div> 
                    <div class="accordion-inner" onclick="loadFile('view.changeMenu_vertical.php')">
                      Manage Vertical Menu
                    </div>
                    <div class="accordion-inner" onclick="loadFile('view.updateCategoryDescription.php')">
                      Manage Category Description
                    </div>
                    <div class="accordion-inner" onclick="loadFile('view.manageBanners.php')">
                      Manage Banners
                    </div>
                     <div class="accordion-inner" onclick="loadFile('view.updateSocialLink.php')">
                     Update Social Link
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
                     Manage Ads
                    </a>
                  </div>
                  <div id="collapseThree" class="accordion-body collapse">
                    <div class="accordion-inner" onclick="loadFile('view.tracker.php?id=1')">
                      Tracker
                    </div>
                     <div class="accordion-inner" onclick="loadFile('view.insertAds.php')">
                      Insert Ads
                    </div> <div class="accordion-inner" onclick="loadFile('view.updateAds.php?value=default&keyword=none')">
                      Update Ads
                    </div> <div class="accordion-inner" onclick="loadFile('view.allads.php?keyword=all')">
                      View All Ads
                    </div>
                  </div>
                </div>
                
                
            <!-- accordian group ends here -->
            </div>
            <!-- class accordian ends here -->
       </div> <!-- span4 ends here -->
