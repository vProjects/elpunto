   
   
</div>
<div class="modal-footer" id="footer">CopyRight VYRAZU LABS : V 2.01</div>
	
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/bootstrap-dropdown.js"></script>
<script type="text/ecmascript" src="js/bootstrap-collapse.js"></script>
</body>
</html>
