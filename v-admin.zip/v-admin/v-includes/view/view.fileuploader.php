<div id="dashboard">
	<div id="mailbox">
    	<blockquote>
          <p>Manage Files of your site</p>
          <small>It will help <cite title="Source Title">you to manage files of your website</cite></small>
        </blockquote>
		<iframe src="fileuploader/index.html" height="100%" width="100%"></iframe>
	</div>
</div>