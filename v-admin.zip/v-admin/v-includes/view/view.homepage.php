<div id="dashboard">
	<div id="homepage">
    	<blockquote>
        	<p>Manage Home Page Content of your site</p>
        	<small>It will help <cite title="Source Title">you to manage content for the home page</cite></small>
        </blockquote>
		<div id="managePageContent">
        <br /><br /><br />
    	<blockquote>
        	<p>Manage Ethics and Believes of your business</p>
        </blockquote>
        		<form class="polls" action="v-includes/functions/function.managehomepage.php" method="post">
                  <fieldset>
                    <div class="form-group">
                      <input type="hidden" name="believe" value="believe" />
                      <label for="exampleInputEmail" class="polllabel" >1st believe</label>
                      <input type="text" class="form-control" name="first_believe" id="exampleInputEmail" placeholder="Enter 1st believe" style="width:500px">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail" class="polllabel" >2nd Believe</label>
                      <input type="text" class="form-control" name="second_believe" id="exampleInputEmail" placeholder="Enter 2nd Believe" style="width:500px">

                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail" class="polllabel" >3rd Believe</label>
                      <input type="text" class="form-control" name="third_believe" id="exampleInputEmail" placeholder="Enter 3rd Believe" style="width:500px">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail" class="polllabel" >4th Believe</label>
                      <input type="text" class="form-control" name="fourth_believe" id="exampleInputEmail" placeholder="Enter 4th Believe" style="width:500px">

                    </div>
                    <button type="submit" class="btn btn-primary" style="margin-left:220px;">Submit</button>
                  </fieldset>
                </form>  

    	<blockquote>
        	<p>Manage Services of your site</p>
        </blockquote>


        		<form class="polls" action="v-includes/functions/function.managehomepage.php" method="post">
                  <fieldset>
                    <div class="form-group">
                      <input type="hidden" name="services" value="services" />
                      <label for="exampleInputEmail" class="polllabel" >1st service</label>
                      <input type="text" class="form-control" name="first_service" id="exampleInputEmail" placeholder="Enter 1st service" style="width:500px">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail" class="polllabel" >2nd service</label>
                      <input type="text" class="form-control" name="second_service" id="exampleInputEmail" placeholder="Enter 2nd service" style="width:500px">

                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail" class="polllabel" >3rd service</label>
                      <input type="text" class="form-control" name="third_service" id="exampleInputEmail" placeholder="Enter 3rd service" style="width:500px">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail" class="polllabel" >4th service</label>
                      <input type="text" class="form-control" name="fourth_service" id="exampleInputEmail" placeholder="Enter 4th service" style="width:500px">

                    </div>
                    <button type="submit" class="btn btn-primary" style="margin-left:220px;">Submit</button>
                  </fieldset>
                </form>  

    	<blockquote>
        	<p>Manage Testimonial of your site</p>
        </blockquote>



        		<form class="polls" action="v-includes/functions/function.managehomepage.php" method="post">
                  <fieldset>
                    <div class="form-group">
                      <input type="hidden" name="testimonial" value="testimonial" />
                      <label for="exampleInputEmail" class="polllabel" >1st Testimonial</label>
                      <textarea class="form-control" name="first_testimonial" id="exampleInputEmail" placeholder="Enter 1st Testimonial" style="width:500px"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail" class="polllabel" >2nd Testimonial</label>
                      <textarea class="form-control" name="second_testimonial" id="exampleInputEmail" placeholder="Enter 2nd Testimonial" style="width:500px"></textarea>

                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail" class="polllabel" >3rd Testimonial</label>
                      <textarea class="form-control" name="third_testimonial" id="exampleInputEmail" placeholder="Enter 3rd Testimonial" style="width:500px"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail" class="polllabel" >4th Testimonial</label>
                      <textarea class="form-control" name="fourth_testimonial" id="exampleInputEmail" placeholder="Enter 4th Testimonial" style="width:500px"></textarea>

                    </div>
                    <button type="submit" class="btn btn-primary" style="margin-left:220px;">Submit</button>
                  </fieldset>
                </form>  



		</div>
	</div>
</div>