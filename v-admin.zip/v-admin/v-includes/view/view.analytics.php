<div id="dashboard">
	<button type="button" class="btn btn-primary" onClick="drawChart('v-includes/view/view.analytics.php');">Generate Chart</button>
	<div id="analytics">
    	<blockquote>
          <p>Check the stats of your site</p>
          <small>It will help <cite title="Source Title">you to understand how famous you are</cite></small>
        </blockquote>

    	<div class="span9">
        	 <div id="chart_div3"></div>  <!-- div responsible to load chart and 
            								you can manipulate chart by changing the home page variable of google charts -->

        </div>
        <div class="span9">
        	<div id="chart_div1"></div>  <!-- div responsible to load chart and 
            								you can manipulate chart by changing the home page variable of google charts -->

        </div> 
        <div class="span9">
        	 <div id="chart_div2"></div>  <!-- div responsible to load chart and 
            								you can manipulate chart by changing the home page variable of google charts -->

        
        
        </div>
        <div class="clearfix"></div>
    
    







	</div>
</div>