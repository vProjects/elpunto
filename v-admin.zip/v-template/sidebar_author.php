<div class="auth_info">
    <h4>TODO</h4>
    <ul>
        <?php $article->getAuthor(); ?>
    </ul>
</div>