<!--footer container starts here-->
<div id="footer_container">
    <div id="footer">
        <div id="footer_text">El punto de venta<br />comercial@elpuntodeventa.com </div>
        <img src="images/d&d.png" alt="VYRAZU LABS" style="float:right;margin-right:15px;" />
    </div>
</div><!--#footer_container ends here-->
</body>
</html>