<!--vertical search container-->
<div class="hori_search_container">
    <form action="#" method="get" name="serach_ads" id="serach_ads">
        <input type="text" class="search_txtbx" placeholder="Search..." name="search_value"/>
        <input type="button" class="search_button" onclick="serach_ads_f()"/>
    </form>
</div>